<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="/styles.css"/>
		<title>Fran's Furniture - Our Furniture</title>
	</head>
	<body>
	<header>
		<section>
			<aside>
				<h3>Opening Hours:</h3>
				<p>Mon-Fri: 09:00-17:30</p>
				<p>Sat: 09:00-17:00</p>
				<p>Sun: 10:00-16:00</p>
			</aside>
			<h1>Fran's Furniture</h1>

		</section>
	</header>
	<nav>
		<ul>
			<li><a href="/">Home</a></li>
			<li><a href="/furniture.php">Our Furniture</a></li>
			<li><a href="/about.html">About Us</a></li>
			<li><a href="/contact.php">Contact us</a></li>
		</ul>

	</nav>
<img src="images/randombanner.php"/>
	<main class="admin">

	<section class="left">
		<ul>
			<li><a href="sofas.php">Sofas</a></li>
			<li><a href="beds.php">Beds</a></li>
			<li><a href="wardrobes.php">Wardrobes</a></li>
		</ul>
	</section>

	<section class="right">

		<h1>Furniture</h1>

	<ul class="furniture">


	<?php
	$pdo = new PDO('mysql:dbname=furniture;host=127.0.0.1', 'student', 'student', [PDO::ATTR_ERRMODE =>  PDO::ERRMODE_EXCEPTION ]);
	$furnitureQuery = $pdo->prepare('SELECT * FROM furniture LIMIT 10');
	$categoryQuery = $pdo->prepare('SELECT * FROM category WHERE id = :id');

	$furnitureQuery->execute();


	foreach ($furnitureQuery as $furniture) {
		$categoryQuery->execute(['id' => $furniture['categoryId']]);
		$category = $categoryQuery->fetch();
		echo '<li>';

		if (file_exists('images/furniture/' . $furniture['id'] . '.jpg')) {
			echo '<a href="images/furniture/' . $furniture['id'] . '.jpg"><img src="images/furniture/' . $furniture['id'] . '.jpg" /></a>';
		}

		echo '<div class="details">';
		echo '<h2>' . $furniture['name'] . '</h2>';
		echo '<h3>' . $category['name'] . '</h3>';
		echo '<h4>£' . $furniture['price'] . '</h4>';
		echo '<p>' . $furniture['description'] . '</p>';

		echo '</div>';
		echo '</li>';
	}

	?>

</ul>

</section>
	</main>


	<footer>
		&copy; Fran's Furniture 2016
	</footer>
</body>
</html>
